#!/bin/sh

#JOB_COMMANDS

# echo " "
# echo "ArCond:---------------- ArCond ------------------- " 
# echo "ArCond: Ending   on host: `hostname` at data: `date`"
# echo "ArCond: from path: `pwd` as identity: `whoami` using $0"
#
exit
